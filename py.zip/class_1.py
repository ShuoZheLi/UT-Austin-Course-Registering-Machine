from selenium import webdriver
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.common.action_chains import ActionChains
import time
import re
import winsound
import threading
import random


def register_1(class_id):
    id = "sl47284"
    password = "Zndndjtc@6754"
    driver_1 = webdriver.Chrome()
    loginUrl = 'https://my.utexas.edu/'
    driver_1.get(loginUrl)
    time.sleep(5)
    driver_1.find_element_by_name('j_username').send_keys(id) #输入用户名
    driver_1.find_element_by_name('j_password').send_keys(password) #输入密码
    driver_1.find_element_by_name('_eventId_proceed').click()
    print("hit Enter to preceed:")
    input()
    base = "https://utdirect.utexas.edu/apps/registrar/course_schedule/20222/"
    driver_1.get(base+str(class_id)+"/")
    
    is_open = False
    while not is_open:
        driver_1.refresh()
        src = driver_1.page_source
        text_found = re.search(r'open', src)
        text_found = str(text_found)
        if text_found != "None":
            is_open = True
        if is_open is False:
            time.sleep(random.randint(1,3))
        
    frequency = 2500  # Set Frequency To 2500 Hertz
    duration = 1000  # Set Duration To 1000 ms == 1 second
    print(str(class_id)+" is open !!")
    while is_open:
        winsound.Beep(frequency, duration)
    
    
    
    


t1 = threading.Thread(target=register_1, args=(51190,))
t2 = threading.Thread(target=register_1, args=(51190,))
t3 = threading.Thread(target=register_1, args=(51190,))

t1.start()
t2.start()
t3.start()

t1.join()
t2.join()
t3.join()


# a = "asdfg" != None